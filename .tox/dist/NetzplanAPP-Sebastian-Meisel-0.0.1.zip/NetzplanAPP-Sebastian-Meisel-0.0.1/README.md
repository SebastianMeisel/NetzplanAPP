# NetzplanAPP

Dies App startet einen Webservice unter [http://127.0.0.1:5000](http://127.0.0.1:5000).
Nutzende haben die Möglichkeit eine Exceldatei mit Projektdaten hochzuladen, aus der
ein Netzplan zur Projektplanung als PDF- und JPG-Datei erstellt wird.
Es wird ein [Template](http://127.0.0.1:5000/static/file/downloads/Projekt.xltx) angeboten,
um eine Excel-Datei zu erstellen, die von der App verarbeitet werden kann.
